using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerContraller : MonoBehaviour
{
    private Rigidbody2D _rb;

    public float speed = 5.0f;

    // Start is called before the first frame update
    void Start()
    {
        _rb = gameObject.GetComponent<Rigidbody2D>();
        
    }

    // Update is called once per frame
    void Update()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");

        _rb.velocity = new Vector2(moveHorizontal * speed,_rb.velocity.y);
    }

    int Addnumbers(int x, int y)
    {
        int sum = x + y;
        return sum;
    }
}
